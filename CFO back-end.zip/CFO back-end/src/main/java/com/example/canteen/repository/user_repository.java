package com.example.canteen.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.canteen.model.user;

@Repository
public interface user_repository extends JpaRepository<user, Long> {

	Optional<user> findByerpNumber(long erpNumber);

	

	boolean existsByerpNumber(long erpNumber);

}