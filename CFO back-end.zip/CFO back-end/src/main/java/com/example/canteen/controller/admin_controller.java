package com.example.canteen.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.example.canteen.model.admin;
import com.example.canteen.service.admin_service;
import com.fasterxml.jackson.databind.ObjectMapper;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/admins")
public class admin_controller {

    @Autowired
    private admin_service adminService;

    // Register a new admin
    @PostMapping("/register")
    public ResponseEntity<String> registerAdminWithPhoto(
            @RequestParam("admin") String adminData,
            @RequestParam("photo") MultipartFile photo) {
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            admin admin = objectMapper.readValue(adminData, admin.class);

            if (photo != null && !photo.isEmpty()) {
                admin.setPhoto(photo.getBytes());
            }

            adminService.registerAdmin(admin);
            return ResponseEntity.status(HttpStatus.CREATED).body("Admin registered successfully!");
        } catch (IOException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error while processing the photo.");
        }
    }
    
 // Login admin by validating username and password
    @PostMapping("/login")
    public ResponseEntity<String> loginAdmin(@RequestBody admin loginDetails) {
        Optional<admin> authenticatedAdmin = adminService.authenticateAdmin(loginDetails.getUsername(), loginDetails.getPassword());
        if (authenticatedAdmin.isPresent()) {
            return ResponseEntity.ok(new HashMap<String, String>().put("Status", "Success"));
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid username or password.");
        }
    }

    // Get admin by ID
    @GetMapping("/profile/{username}")
    public ResponseEntity<HashMap<String, String>> getAdminProfile(@PathVariable String username) {
        Optional<admin> ad = adminService.getAdminByUsername(username);
        if (ad.isPresent()) {
            admin adminData = ad.get();
            HashMap<String, String> profileData = new HashMap<>();
            profileData.put("name", adminData.getName());
            profileData.put("email", adminData.getEmail());
            profileData.put("phone", adminData.getMobileNumber());
            return new ResponseEntity<>(profileData, HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }


    // Get all admins
    @GetMapping
    public ResponseEntity<List<admin>> getAllAdmins() {
        List<admin> admins = adminService.getAllAdmins();
        return new ResponseEntity<>(admins, HttpStatus.OK);
    }

    // Update admin information
    @PutMapping("/{username}")
    public ResponseEntity<admin> updateAdmin(@PathVariable String username, @RequestBody admin updatedAdmin) {
        admin ad = adminService.updateAdmin(username, updatedAdmin);
        return new ResponseEntity<>(ad, HttpStatus.OK);
    }

    // Delete admin by ID
    @DeleteMapping("/{username}")
    public ResponseEntity<Void> deleteAdmin(@PathVariable String username) {
        adminService.deleteAdmin(username);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
