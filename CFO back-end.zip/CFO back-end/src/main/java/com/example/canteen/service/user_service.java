package com.example.canteen.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.canteen.model.user;
import com.example.canteen.repository.user_repository;

@Service
public class user_service {
	
	@Autowired
    private user_repository userRepository;

    // Register a new user
    public user registerUser(user u) {
        return userRepository.save(u);
    }

    // Find user by ID
    public Optional<user> getUserByerpNumber(long erpNumber) {
        return userRepository.findByerpNumber((long) erpNumber);
    }

    // Get all users
    public List<user> getAllUsers() {
        return userRepository.findAll();
    }

    // Update user information
    public user updateUser(long erpNumber, user updatedUser) {
        if(userRepository.existsByerpNumber((long) erpNumber)) {
            updatedUser.setErpNumber((long)erpNumber);
            return userRepository.save(updatedUser);
        } else {
            throw new RuntimeException("user not found");
        }
    }

    // Delete a user by ID
    public void deleteUser(int erpNumber) {
        userRepository.findByerpNumber((long) erpNumber);
    }
    
    // Method to authenticate user by ERP number and password
    public Optional<user> authenticateUser(long erpNumber, String password) {
        Optional<user> user = userRepository.findByerpNumber(erpNumber);
        if (user.isPresent() && user.get().getPassword().equals(password)) {
            return user;
        }
        return Optional.empty();
    }

}