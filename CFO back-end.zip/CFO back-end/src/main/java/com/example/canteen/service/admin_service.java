package com.example.canteen.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.canteen.model.admin;
import com.example.canteen.repository.admin_repository;

@Service
public class admin_service {

    @Autowired
    private admin_repository adminRepository;

    // Register a new admin
    public admin registerAdmin(admin ad) {
        return adminRepository.save(ad);
    }

    // Find admin by username
    public Optional<admin> getAdminByUsername(String username) {
        return adminRepository.findById(username); // Corrected method
    }

    // Get all admins
    public List<admin> getAllAdmins() {
        return adminRepository.findAll();
    }

    // Update admin information
    public admin updateAdmin(String username, admin updatedAdmin) {
        if (adminRepository.existsById(username)) { // Check if username exists
            updatedAdmin.setUsername(username); // Set the primary key
            return adminRepository.save(updatedAdmin);
        } else {
            throw new RuntimeException("Admin not found");
        }
    }

    // Delete an admin by username
    public void deleteAdmin(String username) {
        adminRepository.deleteById(username); // Use username as ID
    }
    
    // Authenticate admin by comparing password
    public Optional<admin> authenticateAdmin(String username, String password) {
        Optional<admin> admin = adminRepository.findByUsername(username);
        if (admin.isPresent() && admin.get().getPassword().equals(password)) {
            return admin; // Authentication successful
        }
        return Optional.empty(); // Authentication failed
    }
}
