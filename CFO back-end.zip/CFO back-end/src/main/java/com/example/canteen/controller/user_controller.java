package com.example.canteen.controller;

import java.io.IOException;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.example.canteen.model.user;
import com.example.canteen.service.user_service;
import com.fasterxml.jackson.databind.ObjectMapper;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/users")
public class user_controller {

	@Autowired
    private user_service userService;

    @PostMapping("/register")
    public ResponseEntity<String> registerAdminWithPhoto(
            @RequestParam("user") String userData,
            @RequestParam("photo") MultipartFile photo) {
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            user user = objectMapper.readValue(userData, user.class);

            if (photo != null && !photo.isEmpty()) {
                user.setPhoto(photo.getBytes());
            }

            userService.registerUser(user);
            return ResponseEntity.status(HttpStatus.CREATED).body("User registered successfully!");
        } catch (IOException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body("Error while processing the photo.");
        }
    }
    
    
    @PostMapping("/login")
    public ResponseEntity<String> loginUser(@RequestBody user loginDetails) {
        Optional<user> authenticatedUser = userService.authenticateUser(loginDetails.getErpNumber(), loginDetails.getPassword());
        if (authenticatedUser.isPresent()) {
            return ResponseEntity.ok("Login successful!");
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid ERP number or password.");
        }
    }

    
 
    // Get user by ID
    @GetMapping("/profile/{erpNumber}")
    public ResponseEntity<Map<String, Object>> getUserProfile(@PathVariable int erpNumber) {
        Optional<user> userOptional = userService.getUserByerpNumber(erpNumber);

        if (userOptional.isPresent()) {
            user user = userOptional.get();

            // Create a map with required fields
            Map<String, Object> userProfile = new HashMap<>();
            userProfile.put("name", user.getName());
            userProfile.put("email", user.getEmail());
            userProfile.put("gender", user.getGender());
            userProfile.put("mobileNumber", user.getMobileNumber());

            // Encode photo in Base64 if present
            if (user.getPhoto() != null) {
                String base64Photo = Base64.getEncoder().encodeToString(user.getPhoto());
                userProfile.put("photo", base64Photo);
            } else {
                userProfile.put("photo", null);
            }

            return new ResponseEntity<>(userProfile, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }




    // Get all users
    @GetMapping
    public ResponseEntity<List<user>> getAllUsers() {
        List<user> users = userService.getAllUsers();
        return new ResponseEntity<>(users, HttpStatus.OK);
    }

    // Update user information
    @PutMapping("/{erpNumber}")
    public ResponseEntity<user> updateUser(@PathVariable int erpNumber, @RequestBody user updatedUser) {
        user us = userService.updateUser(erpNumber, updatedUser);
        return new ResponseEntity<>(us, HttpStatus.OK);
    }

    // Delete user by ID
    @DeleteMapping("/{erpNumber}")
    public ResponseEntity<Void> deleteUser(@PathVariable int erpNumber) {
        userService.deleteUser(erpNumber);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}