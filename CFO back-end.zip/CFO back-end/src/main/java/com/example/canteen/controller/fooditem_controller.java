package com.example.canteen.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.example.canteen.model.admin;
import com.example.canteen.model.fooditem;
import com.example.canteen.service.fooditem_service;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
@RequestMapping("/fooditems")
public class fooditem_controller {

    @Autowired
    private fooditem_service foodItemService;

    // Add a new food item
//    @PostMapping
//    public ResponseEntity<fooditem> addFoodItem(@RequestBody fooditem foo) {
//        fooditem addedFoodItem = foodItemService.addFoodItem(foo);
//        return new ResponseEntity<>(addedFoodItem, HttpStatus.CREATED);
  //  }
    @PostMapping("/register")
    public ResponseEntity<Map<String, String>> registerFoodItemWithPhoto(
            @RequestParam("fooditem") String fooditemData,
            @RequestParam("photo") MultipartFile photo) {
        Map<String, String> response = new HashMap<>();
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            fooditem admin = objectMapper.readValue(fooditemData, fooditem.class);

            if (photo != null && !photo.isEmpty()) {
                admin.setPhoto(photo.getBytes());
            }

            foodItemService.addFoodItem(admin);
            response.put("message", "Order placed successfully!");
            return ResponseEntity.status(HttpStatus.CREATED).body(response);
        } catch (IOException e) {
            response.put("error", "Error while processing the photo.");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }


    // Get food item by ID
    @GetMapping("/{id}")
    public ResponseEntity<fooditem> getFoodItemById(@PathVariable int id) {
        Optional<fooditem> foo = foodItemService.getFoodItemById(id);
        return foo.map(value -> new ResponseEntity<>(value, HttpStatus.OK))
                       .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    // Get all food items
    @GetMapping
    public ResponseEntity<List<fooditem>> getAllFoodItems() {
        List<fooditem> foodItems = foodItemService.getAllFoodItems();
        return new ResponseEntity<>(foodItems, HttpStatus.OK);
    }

    // Update food item
    @PutMapping("/{id}")
    public ResponseEntity<fooditem> updateFoodItem(@PathVariable int id, @RequestBody fooditem updatedFoodItem) {
        fooditem foo = foodItemService.updateFoodItem(id, updatedFoodItem);
        return new ResponseEntity<>(foo, HttpStatus.OK);
    }

    // Delete food item
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteFoodItem(@PathVariable int id) {
        foodItemService.deleteFoodItem(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}