import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MainPageComponent } from './components/main-page/main-page.component';
import { AdminRegistrationComponent } from './components/admin-registration/admin-registration.component';
import { UserRegistrationComponent } from './components/user-registration/user-registration.component';
import { CommonModule } from '@angular/common';
import { AdminLoginComponent } from './components/admin-login/admin-login.component';
import { UserLoginComponent } from './components/user-login/user-login.component';
import { UserHomepageComponent } from './components/user-homepage/user-homepage.component';
import { UserMenuComponent } from './components/user-menu/user-menu.component';
import { UserCartComponent } from './components/user-cart/user-cart.component';
import { UserOrdersComponent } from './components/user-orders/user-orders.component';
import { AdminDashboardComponent } from './components/admin-dashboard/admin-dashboard.component';
import { AdminCustomerComponent } from './components/admin-customer/admin-customer.component';
import { AdminMenuComponent } from './components/admin-menu/admin-menu.component';
import { AdminOrderComponent } from './components/admin-order/admin-order.component';
import { AdminFeedbackComponent } from './components/admin-feedback/admin-feedback.component';
import { AdminSalesComponent } from './components/admin-sales/admin-sales.component';
import { AdminSettingComponent } from './components/admin-setting/admin-setting.component';
import { UserProfileComponent } from './components/user-profile/user-profile.component';
import { AdminProfileComponent } from './components/admin-profile/admin-profile.component';
import { UserPaymentComponent } from './components/user-payment/user-payment.component';

export const routes: Routes = [
  { path: '', component: MainPageComponent },
  { path: 'admin', component: AdminRegistrationComponent },

  { path: '', component: MainPageComponent },
  { path: 'adminRegistration', component: AdminRegistrationComponent },
  { path: 'userRegistration', component: UserRegistrationComponent },
  { path: 'adminLogin', component: AdminLoginComponent },
  { path: 'userLogin', component: UserLoginComponent },
  { path: '', redirectTo: '/mainPage', pathMatch: 'full' },
  { path: 'userHomepage', component: UserHomepageComponent },
  { path: 'userMenu', component: UserMenuComponent },
  { path: 'userCart', component: UserCartComponent },
  { path: 'userOrders', component: UserOrdersComponent },
  { path: 'adminDashboard', component: AdminDashboardComponent },
  { path: 'adminCustomer', component: AdminCustomerComponent },
  { path: 'adminMenu', component: AdminMenuComponent },
  { path: 'adminOrder', component: AdminOrderComponent },
  { path: 'adminFeedback', component: AdminFeedbackComponent },
  { path: 'adminSales', component: AdminSalesComponent },
  { path: 'adminSetting', component: AdminSettingComponent },
  { path: 'userProfile', component: UserProfileComponent },
  { path: 'user-profile/:erpNumber', component: UserProfileComponent },
  { path: 'userPayment', component: UserPaymentComponent },
  { path: 'adminProfile', component: AdminProfileComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes), CommonModule],
  exports: [RouterModule],
})
export class AppRoutingModule {}
