import { Component, OnInit } from '@angular/core';
import { UserCartService } from '../../services/user-cart.service';
import { Router } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-user-cart',
  standalone: true,
  imports: [FormsModule, ReactiveFormsModule, CommonModule],
  templateUrl: './user-cart.component.html',
  styleUrls: ['./user-cart.component.css'],
})
export class UserCartComponent implements OnInit {
  cartItems: any[] = [];
  total: number = 0;

  constructor(
    private userCartService: UserCartService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.loadCart();
  }

  // Load cart items and calculate the total price
  loadCart(): void {
    this.cartItems = this.userCartService.getCart();
    this.calculateTotal();
  }

  // Add an item to the cart
  addItem(item: any): void {
    this.userCartService.addItemToCart(item);
    this.loadCart(); // Refresh cart
  }

  // Remove an item from the cart
  removeItem(foodId: number): void {
    this.userCartService.removeItem(foodId);
    this.loadCart(); // Refresh cart
  }

  // Update the quantity of an item in the cart
  updateQuantity(foodId: number, quantity: number): void {
    if (quantity <= 0) {
      alert('Quantity must be greater than zero');
      return;
    }
    this.userCartService.updateQuantity(foodId, quantity);
    this.loadCart(); // Refresh cart
  }

  // Calculate the total price of the cart
  calculateTotal(): void {
    this.total = this.userCartService.calculateTotal();
  }

  // Clear the entire cart
  clearCart(): void {
    this.userCartService.clearCart(); // Clears the cart in the service
    this.loadCart(); // Refresh cart to show it's empty
  }

  // Proceed to checkout (navigate to the checkout page)
  checkout(): void {
    if (this.cartItems.length === 0) {
      alert('Your cart is empty!');
      return;
    }

    // Store the total amount in localStorage before navigating
    localStorage.setItem('totalPrice', this.total.toString());

    // Navigate to the checkout/payment page
    this.router.navigate(['/userPayment']);
  }
}
