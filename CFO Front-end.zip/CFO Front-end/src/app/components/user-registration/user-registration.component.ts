import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { Component } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {
  Router,
  RouterLink,
  RouterLinkActive,
  RouterOutlet,
} from '@angular/router';
import { UsersService } from '../../services/users.service';

@Component({
  selector: 'app-user-registration',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule,
    RouterOutlet,
    RouterLink,
    RouterLinkActive,
  ],
  templateUrl: './user-registration.component.html',
  styleUrl: './user-registration.component.css',
})
export class UserRegistrationComponent {
  user = {
    name: '',
    email: '',
    password: '',
    mobileNumber: '',
    gender: '',
    country: '',
    collegeName: '',
    erpNumber: '',
  };
  SelectedFile1: File | null = null;

  onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files[0]) {
      this.SelectedFile1 = input.files[0];
    }
  }
  constructor(private usersSevices: UsersService) {}

  registerUser() {
    if (this.SelectedFile1) {
      const formData = new FormData();
      formData.append('user', JSON.stringify(this.user));
      formData.append('photo', this.SelectedFile1);

      this.usersSevices.registerUser(formData).subscribe(
        (response) => {
          alert(response); // response will be the plain text "Admin registered successfully!"
        },
        (error) => {
          console.error('Error:', error);
          alert('Failed to register user.');
        }
      );
    } else {
      alert('Please select a photo.');
    }
  }
}
