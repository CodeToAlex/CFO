import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { Component } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {
  Router,
  RouterLink,
  RouterLinkActive,
  RouterOutlet,
} from '@angular/router';
import { UsersService } from '../../services/users.service';

@Component({
  selector: 'app-user-login',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule,
    RouterOutlet,
    RouterLink,
    RouterLinkActive,
  ],

  templateUrl: './user-login.component.html',
  styleUrl: './user-login.component.css',
})
export class UserLoginComponent {
  erpNumber: number = 0; // erpNumber as a long type (in JS/TS it's treated as a number)
  password: string = '';

  constructor(private userService: UsersService, private router: Router) {}

  // Function to handle login action
  loginAsUser() {
    const loginData = {
      erpNumber: this.erpNumber, // Send erpNumber instead of username
      password: this.password,
    };

    this.userService.loginUser(loginData).subscribe({
      next: (response) => {
        alert('Login successful!');
        this.userService.storeUserSession(this.erpNumber);
        this.router.navigate(['/profile']);
        this.router.navigate(['/userHomepage']); // Navigate to user dashboard (updated route)
      },
      error: (error) => {
        alert('Invalid ERP number or password.');
      },
    });
  }

  // The onSubmit function now calls loginAsUser
  onSubmit() {
    this.loginAsUser(); // Call the function for the login logic
  }
}
