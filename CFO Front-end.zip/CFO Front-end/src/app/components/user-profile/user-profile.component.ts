import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { UserProfileService } from '../../services/user-profile.service';

@Component({
  selector: 'app-user-profile',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    RouterOutlet,
    RouterLink,
    RouterLinkActive,
  ],
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.css'],
})
export class UserProfileComponent implements OnInit {
  userData: any = {}; // Holds user profile data
  activeSection: string = 'personal-info'; // Controls which section is displayed
  editMode: boolean = false; // Toggles between edit and view modes

  constructor(private profileService: UserProfileService) {}

  ngOnInit(): void {
    this.fetchUserProfile();
  }

  // Fetch user profile from the API
  fetchUserProfile() {
    this.profileService.getUserProfile().subscribe(
      (data) => {
        this.userData = data; // Store the fetched data
        console.log('User profile fetched successfully:', data);
      },
      (error) => {
        console.error('Error fetching user profile:', error);
      }
    );
  }

  // Toggle edit mode for profile
  toggleEditProfile() {
    this.editMode = !this.editMode;
  }

  // Save changes after editing
  saveProfile() {
    this.profileService.updateUserProfile(this.userData).subscribe(
      (response) => {
        console.log('Profile updated successfully:', response);
        this.toggleEditProfile(); // Switch back to view mode
      },
      (error) => {
        console.error('Error saving profile:', error);
      }
    );
  }

  // Cancel edit mode and reload profile data
  cancelEdit() {
    this.toggleEditProfile(); // Revert edit mode
    this.fetchUserProfile(); // Reload the original data
  }

  // Switch sections in the profile
  showSection(section: string) {
    this.activeSection = section;
  }

  // Log out the user
  logout() {
    localStorage.removeItem('userData'); // Clear user data
    console.log('User logged out successfully.');
  }
}
