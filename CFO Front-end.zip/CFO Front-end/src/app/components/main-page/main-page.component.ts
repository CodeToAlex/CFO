import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {
  Router,
  RouterLink,
  RouterLinkActive,
  RouterOutlet,
} from '@angular/router';

@Component({
  selector: 'app-main-page',
  standalone: true,
  imports: [
    FormsModule,
    ReactiveFormsModule,
    RouterOutlet,
    CommonModule,
    RouterLink,
    RouterLinkActive,
  ],
  templateUrl: './main-page.component.html',
  styleUrl: './main-page.component.css',
})
export class MainPageComponent {
  constructor(private router: Router) {}

  OnClick() {
    this.router.navigate(['/adminRegistration']);
  }

  OnClick2() {
    this.router.navigate(['/userRegistration']);
  }

  selectedRole: string = '';

  // Function to handle selection and navigation
  onLoginSelect() {
    if (this.selectedRole === 'admin') {
      this.router.navigate(['/adminLogin']);
    } else if (this.selectedRole === 'user') {
      this.router.navigate(['/userLogin']);
    }
  }
}
