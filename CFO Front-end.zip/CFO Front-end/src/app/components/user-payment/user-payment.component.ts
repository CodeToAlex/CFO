import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-user-payment',
  standalone: true,
  imports: [
    FormsModule,
    CommonModule,
    HttpClientModule,
    ReactiveFormsModule,
    RouterOutlet,
    RouterLink,
    RouterLinkActive,
  ],
  templateUrl: './user-payment.component.html',
  styleUrls: ['./user-payment.component.css'],
})
export class UserPaymentComponent implements OnInit {
  cart: any[] = []; // Declare a cart array to hold cart items
  totalPrice: number = 0; // Variable to hold total price

  constructor() {}

  ngOnInit(): void {
    this.loadCart(); // Load the cart data from localStorage when the component is initialized
    this.updateOrderSummary(); // Update the order summary based on the cart data

    // Retrieve the total price stored in localStorage
    this.totalPrice = parseFloat(localStorage.getItem('totalPrice') || '0');
  }

  // Load cart items from localStorage
  loadCart(): void {
    this.cart = JSON.parse(localStorage.getItem('cart') || '[]');
    this.updateOrderSummary(); // Update order summary when cart data is loaded
  }

  // Update the order summary with cart items and total price
  updateOrderSummary(): void {
    this.totalPrice = 0; // Reset the total price
    this.cart.forEach((item) => {
      this.totalPrice += item.price; // Calculate total price
    });
  }

  // Handle order placement
  placeOrder(paymentId: string | null = null): void {
    if (paymentId) {
      // Add payment details to the order
      alert(`Order has been placed! Payment ID: ${paymentId}`);
    } else {
      alert('Order has been placed!'); // If no payment, normal order placement
    }

    this.cart = []; // Clear the cart
    localStorage.setItem('cart', JSON.stringify(this.cart)); // Update cart in localStorage
    this.updateOrderSummary(); // Update the order summary after clearing the cart

    window.location.href = '/orderConfirmation'; // Redirect to confirmation page
  }

  // Razorpay payment initiation
  initiatePayment(): void {
    const options = {
      key: 'rzp_test_ykpIQCXJbWgyQi', // Replace with your Razorpay API key
      amount: this.totalPrice * 100, // Amount in paise (multiply total price by 100)
      currency: 'INR',
      name: 'Your Company Name',
      description: 'Test Transaction',
      image: 'https://example.com/your-logo.png',
      order_id: '', // If you have a pre-generated order ID
      handler: (response: any) => {
        console.log('Payment Success:', response);
        alert('Payment Successful!');
        this.placeOrder(); // Call placeOrder after successful payment
      },
      prefill: {
        name: 'John Doe',
        email: 'johndoe@example.com',
        contact: '9999999999',
      },
      notes: {
        address: 'Corporate Office',
      },
      theme: {
        color: '#3399cc',
      },
    };

    const razorpay = new Razorpay(options);
    razorpay.open();
  }

  // New Razorpay payment options (second set)
  initiateCustomPayment(): void {
    const RozarpayOptions = {
      description: 'Sample Razorpay demo',
      currency: 'INR',
      amount: this.totalPrice * 100, // Amount in paise (₹ totalPrice converted to paise)
      name: 'Sai',
      key: 'rzp_test_ykpIQCXJbWgyQi', // Replace with your Razorpay API key
      image: 'https://i.imgur.com/FApqk3D.jpeg',
      prefill: {
        name: 'Sai Kumar',
        email: 'sai@gmail.com',
        phone: '9898989898',
      },
      theme: {
        color: '#6466e3',
      },
      modal: {
        ondismiss: () => {
          console.log('Payment modal dismissed');
        },
      },
    };

    // Success callback after successful payment
    const successCallback = (paymentId: any) => {
      console.log('Payment Successful:', paymentId);
      alert('Payment Successful!');
      this.placeOrder(paymentId); // Pass paymentId to place the order only after payment is successful
    };

    // Failure callback
    const failureCallback = (error: any) => {
      console.log('Payment Failed:', error);
      alert('Payment Failed');
    };

    // Open Razorpay with the custom options
    const razorpay = new Razorpay(RozarpayOptions);
    razorpay.on('payment.failed', failureCallback);
    razorpay.on('payment.success', successCallback);
    razorpay.open();
  }
}
