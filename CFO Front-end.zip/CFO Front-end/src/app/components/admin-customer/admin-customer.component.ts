import { Component } from '@angular/core';

@Component({
  selector: 'app-admin-customer',
  standalone: true,
  imports: [],
  templateUrl: './admin-customer.component.html',
  styleUrl: './admin-customer.component.css'
})
export class AdminCustomerComponent {

}
