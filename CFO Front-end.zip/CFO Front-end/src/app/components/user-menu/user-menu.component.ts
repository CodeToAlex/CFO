import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../services/admin-menu.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { UserCartService } from '../../services/user-cart.service'; // Import UserCartService

@Component({
  selector: 'app-user-menu',
  standalone: true,
  imports: [
    FormsModule,
    CommonModule,
    HttpClientModule,
    ReactiveFormsModule,
    RouterOutlet,
    RouterLink,
    RouterLinkActive,
  ],
  templateUrl: './user-menu.component.html',
  styleUrls: ['./user-menu.component.css'],
})
export class UserMenuComponent implements OnInit {
  menuItems: any[] = [];

  constructor(
    private apiService: ApiService, // Inject ApiService to fetch food items
    private userCartService: UserCartService // Inject UserCartService to manage cart
  ) {}

  ngOnInit(): void {
    // Fetch food items on component initialization
    this.fetchFoodItems();
  }

  // Method to fetch food items from the backend
  fetchFoodItems() {
    this.apiService.getFoodItems().subscribe(
      (response: any) => {
        this.menuItems = response;
      },
      (error) => {
        console.error('Error fetching food items', error);
      }
    );
  }

  // Method to add item to the cart
  addToCart(item: any) {
    this.userCartService.addItemToCart({
      foodItem: item,
      quantity: 1, // Default quantity is 1
    });
    alert(`${item.name} has been added to your cart!`);
  }
}
