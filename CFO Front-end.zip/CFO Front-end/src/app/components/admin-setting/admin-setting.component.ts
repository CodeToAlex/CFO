import { Component } from '@angular/core';

@Component({
  selector: 'app-admin-setting',
  standalone: true,
  imports: [],
  templateUrl: './admin-setting.component.html',
  styleUrl: './admin-setting.component.css'
})
export class AdminSettingComponent {

}
