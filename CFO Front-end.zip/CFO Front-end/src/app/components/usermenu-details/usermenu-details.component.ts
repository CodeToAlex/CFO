import { Component } from '@angular/core';

@Component({
  selector: 'app-usermenu-details',
  standalone: true,
  imports: [],
  templateUrl: './usermenu-details.component.html',
  styleUrl: './usermenu-details.component.css'
})
export class UsermenuDetailsComponent {

}
