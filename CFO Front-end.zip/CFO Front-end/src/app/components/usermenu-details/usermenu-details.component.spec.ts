import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UsermenuDetailsComponent } from './usermenu-details.component';

describe('UsermenuDetailsComponent', () => {
  let component: UsermenuDetailsComponent;
  let fixture: ComponentFixture<UsermenuDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [UsermenuDetailsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UsermenuDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
