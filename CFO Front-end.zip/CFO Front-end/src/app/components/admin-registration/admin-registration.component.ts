import { Component } from '@angular/core';
//import { Router } from '@angular/router';
import { AdminService } from '../../services/admin.service';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent } from '../../app.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, provideHttpClient } from '@angular/common/http';
import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-admin-registration',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule,
    RouterOutlet,
    RouterLink,
    RouterLinkActive,
  ],

  templateUrl: './admin-registration.component.html',
  styleUrl: './admin-registration.component.css',
})
export class AdminRegistrationComponent {
  admin = {
    name: '',
    email: '',
    password: '',
    mobileNumber: '',
    gender: '',
    country: '',
    collegeName: '',
    username: '',
  };

  SelectedFile: File | null = null;
  constructor(private adminService: AdminService) {}

  onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files[0]) {
      this.SelectedFile = input.files[0];
     }
   }

  registerAdmin() {
    if (this.SelectedFile) {
      const formData = new FormData();
      formData.append('admin', JSON.stringify(this.admin));
      formData.append('photo', this.SelectedFile);

      this.adminService.registerAdmin(formData).subscribe(
        (response) => {
          alert(response); // response will be the plain text "Admin registered successfully!"
        },
        (error) => {
          console.error('Error:', error);
          alert('Failed to register admin.');
        }
      );
    } else {
      alert('Please select a photo.');
    }
  }
}
