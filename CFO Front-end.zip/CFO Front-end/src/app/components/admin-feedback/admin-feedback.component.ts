import { Component } from '@angular/core';

@Component({
  selector: 'app-admin-feedback',
  standalone: true,
  imports: [],
  templateUrl: './admin-feedback.component.html',
  styleUrl: './admin-feedback.component.css'
})
export class AdminFeedbackComponent {

}
