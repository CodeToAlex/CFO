import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { Chart } from 'chart.js';
import { AdminProfileService } from '../../services/admin-profile.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin-profile',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule,
    RouterOutlet,
    RouterLink,
    RouterLinkActive,
  ],
  templateUrl: './admin-profile.component.html',
  styleUrls: ['./admin-profile.component.css'], // Corrected plural property
})
export class AdminProfileComponent implements OnInit {
  adminProfile: { name: string; email: string; phone: string } | null = null;
  userData: any = {};

  constructor(
    private adminProfileService: AdminProfileService,
    private router: Router
  ) {}

  ngOnInit(): void {
    // Load admin profile data
    this.loadAdminProfile();
  }

  private loadAdminProfile(): void {
    const username = localStorage.getItem('username'); // Corrected key

    if (username) {
      this.adminProfileService.getUserProfile().subscribe(
        (data) => {
          this.userData = data; // Store the fetched data
          console.log('Admin profile fetched successfully:', data);
        },
        (error) => {
          console.error('Error fetching admin profile:', error);
        }
      );
    } else {
      console.error('Admin username not found in local storage.');
      alert('Admin username not found. Please log in again.');
    }
  }
  /**
   * Initialize charts using Chart.js
   */
  private initializeCharts(): void {
    // Sales Line Chart
    const salesLineCtx = document.getElementById(
      'salesLineChart'
    ) as HTMLCanvasElement;
    new Chart(salesLineCtx, {
      type: 'line',
      data: {
        labels: [
          'Jan',
          'Feb',
          'Mar',
          'Apr',
          'May',
          'Jun',
          'Jul',
          'Aug',
          'Sep',
          'Oct',
          'Nov',
          'Dec',
        ],
        datasets: [
          {
            label: 'Monthly Sales',
            data: [
              500, 700, 800, 600, 750, 900, 1200, 1100, 950, 1200, 1300, 1400,
            ],
            borderColor: 'rgba(75, 192, 192, 1)',
            backgroundColor: 'rgba(75, 192, 192, 0.2)',
          },
        ],
      },
      options: { responsive: true },
    });

    // Sales Pie Chart
    const salesPieCtx = document.getElementById(
      'salesPieChart'
    ) as HTMLCanvasElement;
    new Chart(salesPieCtx, {
      type: 'pie',
      data: {
        labels: ['Burgers', 'Pizzas', 'Pasta', 'Salads', 'Desserts'],
        datasets: [
          {
            data: [300, 500, 200, 100, 150],
            backgroundColor: [
              '#FF6384',
              '#36A2EB',
              '#FFCE56',
              '#4BC0C0',
              '#9966FF',
            ],
          },
        ],
      },
      options: { responsive: true },
    });
  }
}
