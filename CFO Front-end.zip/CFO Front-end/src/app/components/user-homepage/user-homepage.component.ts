import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user-homepage',
  standalone: true,
  imports: [],
  templateUrl: './user-homepage.component.html',
  styleUrl: './user-homepage.component.css',
})
export class UserHomepageComponent {
  constructor(private router: Router) {}

  navigateToSection(section: string): void {
    this.router.navigate(['/userMenu'], { fragment: section });
  }
}
