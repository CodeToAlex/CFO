import { Component } from '@angular/core';

@Component({
  selector: 'app-admin-order',
  standalone: true,
  imports: [],
  templateUrl: './admin-order.component.html',
  styleUrl: './admin-order.component.css'
})
export class AdminOrderComponent {

}
