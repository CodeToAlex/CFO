import { Component } from '@angular/core';

@Component({
  selector: 'app-admin-sales',
  standalone: true,
  imports: [],
  templateUrl: './admin-sales.component.html',
  styleUrl: './admin-sales.component.css'
})
export class AdminSalesComponent {

}
