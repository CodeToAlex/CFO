import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ApiService } from '../../services/admin-menu.service';
import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';

@Component({
  selector: 'app-admin-menu',
  standalone: true,
  imports: [
    FormsModule,
    CommonModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule,
    RouterOutlet,
    RouterLink,
    RouterLinkActive,
  ],
  templateUrl: './admin-menu.component.html',
  styleUrls: ['./admin-menu.component.css'],
})
export class AdminMenuComponent {
  sidebarOpen: boolean = true;

  // Modal control
  isModalOpen: boolean = false;

  // Item data for form and table
  menuItems: any[] = [];
  selectedItem: any = {
    name: '',
    discription: '',
    category: '',
    price: '',
    preparationTime: '',
    availability: true, // Updated to match the 'availability' type as boolean
    photo: '', // Matching the image property in the form
  };

  // Categories for filtering and selection
  categories: string[] = [
    'Pizza',
    'Burger',
    'Maggi',
    'Snacks',
    'Paratha',
    'Dessert',
    'Shakes and Beverages',
  ];

  // Search and filter
  searchQuery: string = '';
  selectedCategory: string = 'all';

  constructor(private apiService: ApiService) {} // Inject ApiService

  // Toggle Sidebar
  toggleSidebar(): void {
    this.sidebarOpen = !this.sidebarOpen;
  }

  // Open Modal
  openModal(): void {
    this.isModalOpen = true;
  }

  // Close Modal
  closeModal(): void {
    this.isModalOpen = false;
    this.resetSelectedItem();
  }
  message: string = ''; // Variable to store the message
  messageType: 'success' | 'error' = 'success'; // Message type for styling

  // Add or Edit item
  // In AdminMenuComponent

  // Fetch Food Items after form submission or on component initialization
  fetchFoodItems(): void {
    this.apiService.getFoodItems().subscribe({
      next: (response) => {
        this.menuItems = response || []; // Assuming response contains the food items
        console.log('Fetched food items:', this.menuItems);
      },
      error: (err: any) => {
        console.error('Error fetching food items', err);
      },
    });
  }

  submitForm(): void {
    if (
      this.selectedItem.name &&
      this.selectedItem.category &&
      this.selectedItem.price
    ) {
      const formData = new FormData();
      formData.append('fooditem', JSON.stringify(this.selectedItem));
      if (this.selectedItem.photo) {
        formData.append('photo', this.selectedItem.photo);
      }

      this.apiService.addOrEditFoodItem(formData).subscribe({
        next: (response) => {
          this.message = response.message || 'Item added/updated successfully!';
          this.messageType = 'success';
          console.log(this.message, response);

          // Fetch updated list of food items from the backend
          this.fetchFoodItems();

          // Close modal and reset the selected item
          this.closeModal();
        },
        error: (err: any) => {
          this.message =
            err.error.error || 'Error while adding/updating food item';
          this.messageType = 'error';
          console.error(this.message, err);
        },
      });
    } else {
      alert('Please fill all required fields.');
    }
  }

  ngOnInit(): void {
    // Fetch the food items when the component initializes
    this.fetchFoodItems();
  }

  // Reset selected item form
  resetSelectedItem(): void {
    this.selectedItem = {
      name: '',
      discription: '',
      category: '',
      price: '',
      preparationTime: '',
      availability: true,
      photo: '',
    };
  }

  onFileSelected(event: any): void {
    const file = event.target.files[0];
    if (file) {
      this.selectedItem.photo = file; // Store the file object
    }
  }

  // Edit item
  editItem(item: any): void {
    this.selectedItem = { ...item };
    this.isModalOpen = true;
  }

  // Delete item
  deleteItem(id: number): void {
    this.menuItems = this.menuItems.filter((item) => item.foodId !== id);
  }

  // Filtered menu items
  filteredItems(): any[] {
    return this.menuItems.filter((item) => {
      const matchesQuery = item.name
        .toLowerCase()
        .includes(this.searchQuery.toLowerCase());
      const matchesCategory =
        this.selectedCategory === 'all' ||
        item.category === this.selectedCategory;
      return matchesQuery && matchesCategory;
    });
  }

  // Handle file input for image preview
  onImageChange(event: any): void {
    const file = event.target.files[0];
    if (file) {
      this.selectedItem = file;
      const reader = new FileReader();
      reader.onload = (e: any) => {
        this.selectedItem.image = e.target.result;
      };
      reader.readAsDataURL(file);
    }
  }

  newCategory: string = ''; // holds the new category input

  addCategory(): void {
    if (this.newCategory && !this.categories.includes(this.newCategory)) {
      this.categories.push(this.newCategory);
      this.newCategory = ''; // clear input field
    } else {
      alert('Category already exists or invalid input');
    }
  }
}
