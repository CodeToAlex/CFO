import { CommonModule } from '@angular/common';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Component } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {
  Router,
  RouterLink,
  RouterLinkActive,
  RouterOutlet,
} from '@angular/router';
import { AdminService } from '../../services/admin.service';

@Component({
  selector: 'app-admin-login',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule,
    RouterOutlet,
    RouterLink,
    RouterLinkActive,
  ],

  templateUrl: './admin-login.component.html',
  styleUrl: './admin-login.component.css',
})
export class AdminLoginComponent {
  username: string = '';
  password: string = '';

  constructor(private adminService: AdminService, private router: Router) {}

  // Function to handle login action
  loginAsAdmin() {
    const loginData = {
      username: this.username,
      password: this.password,
    };

    this.adminService.loginAdmin(loginData).subscribe({
      next: (response) => {
        console.log(response);

        alert('Login successful!');
        this.adminService.storeAdminSession(this.username);
        this.router.navigate(['/profile']);
        this.router.navigate(['/adminDashboard']); // Navigate to admin dashboard
      },
      error: (error) => {
        console.log(error);

        alert('Invalid username or password.');
      },
    });
  }

  // The onSubmit function now calls loginAsAdmin
  onSubmit() {
    this.loginAsAdmin(); // Call the function for the login logic
  }
}
