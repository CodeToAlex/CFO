import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { MainPageComponent } from './components/main-page/main-page.component';
import { AdminRegistrationComponent } from './components/admin-registration/admin-registration.component';
import { UserRegistrationComponent } from './components/user-registration/user-registration.component';
import { FormsModule } from '@angular/forms';
import { AdminLoginComponent } from './components/admin-login/admin-login.component';
import { UserLoginComponent } from './components/user-login/user-login.component';
import { UserHomepageComponent } from './components/user-homepage/user-homepage.component';
import { UserMenuComponent } from './components/user-menu/user-menu.component';
import { UserCartComponent } from './components/user-cart/user-cart.component';
import { UserOrdersComponent } from './components/user-orders/user-orders.component';
import { AdminDashboardComponent } from './components/admin-dashboard/admin-dashboard.component';
import { AdminCustomerComponent } from './components/admin-customer/admin-customer.component';
import { AdminMenuComponent } from './components/admin-menu/admin-menu.component';
import { AdminOrderComponent } from './components/admin-order/admin-order.component';
import { AdminFeedbackComponent } from './components/admin-feedback/admin-feedback.component';
import { AdminSalesComponent } from './components/admin-sales/admin-sales.component';
import { AdminSettingComponent } from './components/admin-setting/admin-setting.component';
import { UserProfileComponent } from './components/user-profile/user-profile.component';
import { AdminProfileComponent } from './components/admin-profile/admin-profile.component';
import { UserPaymentComponent } from './components/user-payment/user-payment.component';

@Component({
  selector: 'app-root',
  standalone: true,

  imports: [
    RouterOutlet,
    MainPageComponent,
    AdminRegistrationComponent,
    UserRegistrationComponent,
    FormsModule,
    AdminLoginComponent,
    UserLoginComponent,
    UserHomepageComponent,
    UserMenuComponent,
    UserCartComponent,
    UserOrdersComponent,
    AdminDashboardComponent,
    AdminCustomerComponent,
    UserProfileComponent,
    AdminOrderComponent,
    AdminFeedbackComponent,
    AdminSalesComponent,
    AdminSettingComponent,
    AdminMenuComponent,
    AdminProfileComponent,
    UserPaymentComponent,
  ],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css',
})
export class AppComponent {
  title = 'cm';
}
