import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class ApiService {
  constructor(private http: HttpClient) {}

  private foodItemUrl = 'http://localhost:8080/fooditems'; // Update to your backend endpoint for food items

  // Add or Edit Food Item
  addOrEditFoodItem(foodItemData: FormData): Observable<any> {
    return this.http.post(this.foodItemUrl + '/register', foodItemData, {
      responseType: 'json',
    });
  }

  // Fetch Food Items from the backend
  getFoodItems(): Observable<any> {
    return this.http.get(this.foodItemUrl, { responseType: 'json' });
  }
}
