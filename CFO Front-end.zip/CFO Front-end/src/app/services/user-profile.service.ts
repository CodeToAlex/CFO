import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class UserProfileService {
  private userProfileUrl = 'http://localhost:8080/users/profile'; // Backend profile endpoint

  constructor(private http: HttpClient) {}

  // Fetch user profile using ERP number
  getUserProfile(): Observable<any> {
    const erpNumber = localStorage.getItem('erpNumber'); // Get ERP from storage
    if (!erpNumber) {
      throw new Error('ERP number not found. User might not be logged in.');
    }
    return this.http.get(
      `${this.userProfileUrl}/${encodeURIComponent(erpNumber)}`
    );
  }

  // Update user profile
  updateUserProfile(userData: any): Observable<any> {
    return this.http.put(this.userProfileUrl, userData);
  }
}
