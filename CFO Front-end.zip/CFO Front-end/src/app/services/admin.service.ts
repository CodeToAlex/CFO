import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class AdminService {
  constructor(private http: HttpClient) {}

  private AdminLoginUrl = 'http://localhost:8080/admins/login'; // Spring Boot Endpoint for login
  // Admin Login
  loginAdmin(loginData: {
    username: string;
    password: string;
  }): Observable<any> {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
    });

    // Make POST request to validate login
    return this.http.post(this.AdminLoginUrl, loginData, { headers });
  }
  storeAdminSession(username: string): void {
    localStorage.setItem('username', username); // Store username in local storage
  }

  private AdminbaseUrl = 'http://localhost:8080/admins/register'; // Spring Boot Endpoint

  //Admin Registrer
  registerAdmin(adminData: FormData): Observable<any> {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
    });
    return this.http.post(this.AdminbaseUrl, adminData, {
      responseType: 'text',
    });
  }
}
