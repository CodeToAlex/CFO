import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class UserSessionService {
  private erpNumber: number | null = null;

  setErpNumber(erpNumber: number) {
    this.erpNumber = erpNumber;
  }

  getErpNumber(): number | null {
    return this.erpNumber;
  }

  clearSession() {
    this.erpNumber = null;
  }
}
