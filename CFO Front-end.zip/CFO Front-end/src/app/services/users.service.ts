import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class UsersService {
  constructor(private http: HttpClient) {}

  private userLoginUrl = 'http://localhost:8080/users/login'; // Your backend endpoint

  // User login
  loginUser(loginData: {
    erpNumber: number;
    password: string;
  }): Observable<any> {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
    });
    return this.http.post(this.userLoginUrl, loginData, {
      responseType: 'text',
    });
  }
  storeUserSession(erpNumber: number): void {
    localStorage.setItem('erpNumber', erpNumber.toString());
  }

  private userBaseUrl = 'http://localhost:8080/users/register';

  //User Register
  registerUser(userData: FormData): Observable<any> {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
    });
    return this.http.post(this.userBaseUrl, userData, { responseType: 'text' });
  }
}
