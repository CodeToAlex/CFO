import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class AdminProfileService {
  private readonly LOCAL_STORAGE_KEY = 'adminProfile';

  private readonly userProfileUrl = 'http://localhost:8080/admins/profile'; // Backend endpoint

  constructor(private http: HttpClient) {}

  /**
   * Fetch user profile from the server by username
   * @param username - Admin's username
   * @returns Observable with the admin profile
   */

  getUserProfile(): Observable<any> {
    const username = localStorage.getItem('username'); // Correct key
    if (!username) {
      throw new Error('Username not found in local storage.');
    }
    return this.http.get(
      `${this.userProfileUrl}/${encodeURIComponent(username)}`
    );
  }

  /**
   * Save admin profile data to local storage
   * @param profile - Admin profile object containing name, email, and phone
   */
  saveProfileToLocal(profile: {
    name: string;
    email: string;
    phone: string;
  }): void {
    localStorage.setItem(this.LOCAL_STORAGE_KEY, JSON.stringify(profile));
  }

  /**
   * Get admin profile data from local storage
   * @returns The admin profile object or null if not found
   */
  getProfileFromLocal(): { name: string; email: string; phone: string } | null {
    const profileData = localStorage.getItem(this.LOCAL_STORAGE_KEY);
    return profileData ? JSON.parse(profileData) : null;
  }

  /**
   * Clear admin profile data from local storage
   */
  clearProfileFromLocal(): void {
    localStorage.removeItem(this.LOCAL_STORAGE_KEY);
  }

  /**
   * Check if an admin profile exists in local storage
   * @returns true if profile exists, otherwise false
   */
  isProfileSaved(): boolean {
    return localStorage.getItem(this.LOCAL_STORAGE_KEY) !== null;
  }
}
