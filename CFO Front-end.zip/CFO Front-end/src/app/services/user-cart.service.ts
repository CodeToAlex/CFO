import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class UserCartService {
  private cart: any[] = JSON.parse(localStorage.getItem('cart') || '[]');

  constructor() {}

  // Get the current cart items
  getCart() {
    return this.cart;
  }

  // Add an item to the cart
  addItemToCart(item: any) {
    // Check if the item is already in the cart
    const existingItem = this.cart.find(
      (cartItem) => cartItem.foodItem.id === item.foodItem.id
    );

    if (existingItem) {
      // If the item already exists, increase the quantity
      existingItem.quantity += item.quantity;
    } else {
      // If the item does not exist, add it to the cart
      this.cart.push(item);
    }

    // Update the cart in localStorage
    this.updateCart();
  }

  // Remove an item from the cart
  removeItem(foodId: number) {
    this.cart = this.cart.filter((item) => item.foodItem.id !== foodId);
    this.updateCart();
  }

  // Update the quantity of an item in the cart
  updateQuantity(foodId: number, quantity: number) {
    const item = this.cart.find((item) => item.foodItem.id === foodId);
    if (item) {
      item.quantity = quantity;
      this.updateCart();
    }
  }

  // Clear the cart
  clearCart() {
    this.cart = [];
    this.updateCart();
  }

  // Update the cart in localStorage
  private updateCart() {
    localStorage.setItem('cart', JSON.stringify(this.cart));
  }

  // Calculate the total price of items in the cart
  calculateTotal(): number {
    return this.cart.reduce(
      (sum, item) => sum + item.foodItem.price * item.quantity,
      0
    );
  }
}
